"""
Configuration for cli
"""
from .cli import app
app()
